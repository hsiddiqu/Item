import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;  
import java.util.List;  

class ListTest {
	private List<String> numbers  = new ArrayList<String>();
	
	@Test
	public void nums() {
		List<String> expected = ArrayList(" output 5 numbers");
		assertLinesMatch(expected, numbers); 
	}
	
       @Test
	private List<String> ArrayList(String string) {
		System.out.print("1,2,3,4,5");
		assertLinesMatch(numbers, numbers);
		return numbers;
		
	}


	
	}


